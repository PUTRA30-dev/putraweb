# Web Romantis 💕

Website personal buat pacar kamu. Tidak ada halaman "login admin" — begitu dibuka,
web akan menampilkan sapaan **"Halo Sayang"** dengan kolom jawaban bebas.

- Kalau yang mengetik menjawab **`IYA`** (huruf besar/kecil sama saja) → mode rahasia
  aktif (tombol bulat "+" di pojok kanan bawah muncul, isinya untuk menambah foto,
  catatan, pertanyaan, dan mengganti lagu).
- Kalau jawabannya apapun selain itu → tampilan biasa: galeri foto, catatan cinta,
  dan pertanyaan receh, tanpa ada tombol tambah apapun. Jadi pacar kamu tidak akan
  pernah tahu ada "mode admin".
- Lagu latar otomatis diputar begitu jawaban gerbang dikirim (butuh interaksi klik
  dulu karena aturan browser, tapi klik tombol "Kirim" itu sendiri sudah cukup).

## 1. Coba dulu di komputer sendiri

Butuh [Node.js](https://nodejs.org) versi 18 ke atas.

```bash
cd web-romantis
npm install
npm start
```

Lalu buka `http://localhost:3000` di browser.

## 2. Deploy ke VPS

Asumsi VPS pakai Ubuntu, dan kamu akses lewat SSH.

### a. Install Node.js di VPS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v
```

### b. Upload folder proyek

Dari komputer kamu (bukan dari VPS), pakai `scp` atau `rsync`:

```bash
scp -r web-romantis root@ALAMAT_IP_VPS:/var/www/web-romantis
```

(Ganti `ALAMAT_IP_VPS` dengan IP VPS kamu. Kalau pakai `rsync` juga bisa, tinggal
`rsync -avz web-romantis/ root@ALAMAT_IP_VPS:/var/www/web-romantis/`.)

### c. Install dependency & jalankan

Masuk ke VPS via SSH:

```bash
ssh root@ALAMAT_IP_VPS
cd /var/www/web-romantis
npm install
```

Supaya web tetap jalan walau SSH ditutup, pakai **pm2**:

```bash
sudo npm install -g pm2
pm2 start server.js --name web-romantis
pm2 save
pm2 startup   # ikuti instruksi yang muncul biar auto-start saat VPS reboot
```

Sekarang web sudah jalan di `http://ALAMAT_IP_VPS:3000`.

### d. (Opsional tapi disarankan) Pasang domain + HTTPS pakai Nginx

Kalau kamu punya domain (misal `sayang.namakamu.com`), arahkan DNS-nya (A record)
ke IP VPS, lalu:

```bash
sudo apt install -y nginx
sudo nano /etc/nginx/sites-available/web-romantis
```

Isi filenya:

```nginx
server {
    listen 80;
    server_name sayang.namakamu.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Aktifkan dan pasang SSL gratis:

```bash
sudo ln -s /etc/nginx/sites-available/web-romantis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d sayang.namakamu.com
```

Sekarang web bisa diakses lewat `https://sayang.namakamu.com` 🎉

## 3. Cara isi konten pertama kali

1. Buka webnya, di kolom jawaban ketik `IYA`, klik Kirim.
2. Tombol "+" pink muncul di pojok kanan bawah — klik itu.
3. Upload foto-foto kalian, tulis beberapa catatan manis, tambahkan pertanyaan
   receh, dan upload lagu favorit kalian berdua.
4. Setelah selesai isi konten, kirim link webnya ke pacar kamu. Kalau dia buka dan
   menjawab apapun selain "IYA", dia cuma akan lihat tampilan galeri/catatan/pertanyaan
   yang cantik tanpa tombol tambah apapun.

## Catatan teknis

- Data (foto, catatan, pertanyaan, info lagu) disimpan di `data/content.json` dan
  file asli foto/lagu di folder `uploads/`. Kalau mau backup, cukup copy dua folder
  itu (`data/` dan `uploads/`).
- Tidak ada database eksternal, semuanya file-based — cocok untuk VPS kecil.
