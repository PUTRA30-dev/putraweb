const state = { mode: 'guest', content: null };

const gate = document.getElementById('gate');
const app = document.getElementById('app');
const gateForm = document.getElementById('gate-form');
const gateInput = document.getElementById('gate-input');
const bgm = document.getElementById('bgm');
const fab = document.getElementById('fab-add');
const addPanel = document.getElementById('add-panel');

/* ===== HEARTS BACKGROUND (selalu jalan, dari sebelum gerbang) ===== */
function spawnHeart() {
  const el = document.createElement('div');
  el.className = 'floating-heart';
  const emojis = ['💗','💕','💖','💓','🌸','✨'];
  el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
  el.style.left = Math.random() * 100 + 'vw';
  el.style.fontSize = 14 + Math.random() * 18 + 'px';
  const duration = 6 + Math.random() * 6;
  el.style.animationDuration = duration + 's';
  document.getElementById('hearts-bg').appendChild(el);
  setTimeout(() => el.remove(), duration * 1000);
}
setInterval(spawnHeart, 500);
for (let i = 0; i < 10; i++) setTimeout(spawnHeart, i * 200);

/* ===== GERBANG RAHASIA ===== */
gateForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const val = gateInput.value.trim().toUpperCase();
  state.mode = val === 'IYA' ? 'secret' : 'guest';
  sessionStorage.setItem('mode', state.mode);

  // coba mainkan audio dalam konteks interaksi user
  bgm.muted = false;
  bgm.play().catch(() => {});

  gate.classList.add('hide');
  await loadContent();
  renderAll();
  applyMode();
  setTimeout(() => app.classList.add('show'), 60);
});

async function loadContent() {
  const res = await fetch('/api/content');
  state.content = await res.json();
  if (state.content.song) {
    bgm.src = state.content.song.url;
    bgm.play().catch(() => {});
  }
}

function applyMode() {
  if (state.mode === 'secret') {
    fab.style.display = 'flex';
  } else {
    fab.style.display = 'none';
  }
}

/* ===== TABS ===== */
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
  });
});

/* ===== RENDER GALERI ===== */
function renderGaleri() {
  const grid = document.getElementById('galeri-grid');
  const empty = document.getElementById('galeri-empty');
  grid.innerHTML = '';
  const photos = state.content.photos || [];
  empty.style.display = photos.length ? 'none' : 'block';
  photos.forEach((p) => {
    const item = document.createElement('div');
    item.className = 'galeri-item';
    item.innerHTML = `
      <img src="${p.url}" alt="foto kenangan" />
      ${p.caption ? `<div class="galeri-caption">${escapeHtml(p.caption)}</div>` : ''}
      ${state.mode === 'secret' ? `<button class="del-btn" data-type="photos" data-id="${p.id}">✕</button>` : ''}
    `;
    grid.appendChild(item);
  });
  bindDeleteButtons();
}

/* ===== RENDER CATATAN ===== */
function renderCatatan() {
  const list = document.getElementById('catatan-list');
  const empty = document.getElementById('catatan-empty');
  list.innerHTML = '';
  const notes = state.content.notes || [];
  empty.style.display = notes.length ? 'none' : 'block';
  notes.forEach((n) => {
    const card = document.createElement('div');
    card.className = 'catatan-card';
    card.innerHTML = `
      ${escapeHtml(n.text)}
      ${state.mode === 'secret' ? `<button class="del-btn" data-type="notes" data-id="${n.id}">✕</button>` : ''}
    `;
    list.appendChild(card);
  });
  bindDeleteButtons();
}

/* ===== RENDER PERTANYAAN ===== */
let currentQIndex = 0;
function renderPertanyaan() {
  const questions = state.content.questions || [];
  const textEl = document.getElementById('pertanyaan-text');
  if (!questions.length) {
    textEl.textContent = 'belum ada pertanyaan nih~';
    return;
  }
  textEl.textContent = questions[currentQIndex % questions.length].text;
}
document.getElementById('pertanyaan-next').addEventListener('click', () => {
  currentQIndex++;
  renderPertanyaan();
});

function renderAll() {
  renderGaleri();
  renderCatatan();
  renderPertanyaan();
  renderManageList();
  if (state.content.song) {
    document.getElementById('song-current').textContent = 'Lagu saat ini: ' + (state.content.song.name || 'terpasang');
  }
}

function bindDeleteButtons() {
  document.querySelectorAll('.del-btn').forEach((btn) => {
    btn.onclick = async () => {
      const type = btn.dataset.type;
      const id = btn.dataset.id;
      await fetch(`/api/${type}/${id}`, { method: 'DELETE' });
      await loadContent();
      renderAll();
    };
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* ===== PANEL TAMBAH (mode rahasia) ===== */
fab.addEventListener('click', () => addPanel.classList.add('show'));
document.getElementById('close-panel').addEventListener('click', () => addPanel.classList.remove('show'));

document.getElementById('form-photo').addEventListener('submit', async (e) => {
  e.preventDefault();
  const file = document.getElementById('input-photo').files[0];
  const caption = document.getElementById('input-photo-caption').value;
  if (!file) return;
  const fd = new FormData();
  fd.append('photo', file);
  fd.append('caption', caption);
  await fetch('/api/photos', { method: 'POST', body: fd });
  e.target.reset();
  await loadContent();
  renderAll();
});

document.getElementById('form-note').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = document.getElementById('input-note').value;
  await fetch('/api/notes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  e.target.reset();
  await loadContent();
  renderAll();
});

document.getElementById('form-question').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = document.getElementById('input-question').value;
  await fetch('/api/questions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  e.target.reset();
  await loadContent();
  renderAll();
});

document.getElementById('form-song').addEventListener('submit', async (e) => {
  e.preventDefault();
  const file = document.getElementById('input-song').files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('song', file);
  fd.append('name', file.name);
  await fetch('/api/song', { method: 'POST', body: fd });
  e.target.reset();
  await loadContent();
  renderAll();
  bgm.play().catch(() => {});
});

function renderManageList() {
  const wrap = document.getElementById('manage-list');
  if (!wrap) return;
  wrap.innerHTML = '';
  (state.content.notes || []).forEach((n) => {
    wrap.appendChild(makeManageRow('📝 ' + n.text.slice(0, 30), 'notes', n.id));
  });
  (state.content.questions || []).forEach((q) => {
    wrap.appendChild(makeManageRow('❓ ' + q.text.slice(0, 30), 'questions', q.id));
  });
  (state.content.photos || []).forEach((p) => {
    wrap.appendChild(makeManageRow('📸 ' + (p.caption || 'foto'), 'photos', p.id));
  });
}
function makeManageRow(label, type, id) {
  const row = document.createElement('div');
  row.className = 'manage-row';
  row.innerHTML = `<span>${escapeHtml(label)}</span><button data-type="${type}" data-id="${id}">hapus</button>`;
  row.querySelector('button').onclick = async () => {
    await fetch(`/api/${type}/${id}`, { method: 'DELETE' });
    await loadContent();
    renderAll();
  };
  return row;
}
