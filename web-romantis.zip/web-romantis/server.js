const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_FILE = path.join(__dirname, 'data', 'content.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const PHOTOS_DIR = path.join(UPLOADS_DIR, 'photos');
const MUSIC_DIR = path.join(UPLOADS_DIR, 'music');

// pastikan folder ada
[UPLOADS_DIR, PHOTOS_DIR, MUSIC_DIR, path.dirname(DATA_FILE)].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// data default kalau belum ada
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(
    DATA_FILE,
    JSON.stringify(
      {
        notes: [
          { id: '1', text: 'Ini catatan cinta pertama, ganti/tambah lewat mode rahasia ya 💕' }
        ],
        photos: [],
        questions: [
          { id: '1', text: 'Kamu lagi mikirin siapa nih? 😏' }
        ],
        song: null
      },
      null,
      2
    )
  );
}

function readData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
}
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.use(express.json());
app.use('/uploads', express.static(UPLOADS_DIR));
app.use(express.static(path.join(__dirname, 'public')));

const photoUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, PHOTOS_DIR),
    filename: (req, file, cb) =>
      cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + path.extname(file.originalname))
  }),
  limits: { fileSize: 15 * 1024 * 1024 }
});

const songUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, MUSIC_DIR),
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
  }),
  limits: { fileSize: 30 * 1024 * 1024 }
});

// ambil semua konten
app.get('/api/content', (req, res) => {
  res.json(readData());
});

// ==== FOTO ====
app.post('/api/photos', photoUpload.single('photo'), (req, res) => {
  const data = readData();
  const item = {
    id: Date.now().toString(),
    url: '/uploads/photos/' + req.file.filename,
    caption: req.body.caption || ''
  };
  data.photos.push(item);
  writeData(data);
  res.json(item);
});

app.delete('/api/photos/:id', (req, res) => {
  const data = readData();
  const item = data.photos.find((p) => p.id === req.params.id);
  if (item) {
    const filePath = path.join(__dirname, item.url);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
  data.photos = data.photos.filter((p) => p.id !== req.params.id);
  writeData(data);
  res.json({ ok: true });
});

// ==== CATATAN ====
app.post('/api/notes', (req, res) => {
  const data = readData();
  const item = { id: Date.now().toString(), text: req.body.text || '' };
  data.notes.push(item);
  writeData(data);
  res.json(item);
});

app.delete('/api/notes/:id', (req, res) => {
  const data = readData();
  data.notes = data.notes.filter((n) => n.id !== req.params.id);
  writeData(data);
  res.json({ ok: true });
});

// ==== PERTANYAAN ====
app.post('/api/questions', (req, res) => {
  const data = readData();
  const item = { id: Date.now().toString(), text: req.body.text || '' };
  data.questions.push(item);
  writeData(data);
  res.json(item);
});

app.delete('/api/questions/:id', (req, res) => {
  const data = readData();
  data.questions = data.questions.filter((q) => q.id !== req.params.id);
  writeData(data);
  res.json({ ok: true });
});

// ==== LAGU ====
app.post('/api/song', songUpload.single('song'), (req, res) => {
  const data = readData();
  if (data.song && data.song.url) {
    const oldPath = path.join(__dirname, data.song.url);
    if (fs.existsSync(oldPath)) {
      try {
        fs.unlinkSync(oldPath);
      } catch (e) {}
    }
  }
  data.song = { url: '/uploads/music/' + req.file.filename, name: req.body.name || req.file.originalname };
  writeData(data);
  res.json(data.song);
});

app.delete('/api/song', (req, res) => {
  const data = readData();
  if (data.song && data.song.url) {
    const oldPath = path.join(__dirname, data.song.url);
    if (fs.existsSync(oldPath)) {
      try {
        fs.unlinkSync(oldPath);
      } catch (e) {}
    }
  }
  data.song = null;
  writeData(data);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Web romantis jalan di http://localhost:${PORT}`);
});
